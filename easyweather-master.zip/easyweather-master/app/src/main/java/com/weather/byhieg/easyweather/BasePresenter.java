package com.weather.byhieg.easyweather;

/**
 * Created by byhieg on 17/5/21.
 * Contact with byhieg@gmail.com
 */

public interface BasePresenter {

    void start();
}
