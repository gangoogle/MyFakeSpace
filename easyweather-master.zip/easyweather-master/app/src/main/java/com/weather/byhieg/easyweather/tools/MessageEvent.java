package com.weather.byhieg.easyweather.tools;

/**
 * Created by byhieg on 17/2/5.
 * Contact with byhieg@gmail.com
 */

public class MessageEvent {

    private int message;

    public MessageEvent(int message) {
        this.message = message;
    }

    public int getMessage() {
        return message;
    }

    public void setMessage(int message) {
        this.message = message;
    }
}
