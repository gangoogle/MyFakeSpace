package com.weather.byhieg.easyweather;

/**
 * Created by byhieg on 17/5/21.
 * Contact with byhieg@gmail.com
 */

public interface BaseView<T> {

    void setPresenter(T presenter);
}
