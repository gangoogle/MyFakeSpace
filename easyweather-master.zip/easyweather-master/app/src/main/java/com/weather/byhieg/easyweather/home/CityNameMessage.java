package com.weather.byhieg.easyweather.home;

/**
 * Created by byhieg on 2017/7/27.
 * Contact with byhieg@gmail.com
 */

public class CityNameMessage {

    private String cityName;

    public CityNameMessage(String cityName){
        this.cityName = cityName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
}
