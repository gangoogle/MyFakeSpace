package cn.byhieg.monitor;

/**
 * Created by byhieg on 2017/7/25.
 * Contact with byhieg@gmail.com
 */

public class TimeMonitorConfig {

    public static final int TIME_MONITOR_ID_APPLICATION_START = 1;
}
