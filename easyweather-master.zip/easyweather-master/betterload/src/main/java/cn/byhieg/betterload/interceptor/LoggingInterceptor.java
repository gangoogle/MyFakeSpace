package cn.byhieg.betterload.interceptor;

/**
 * Created by byhieg on 17/3/2.
 * Contact with byhieg@gmail.com
 */

public class LoggingInterceptor {

    public LoggingInterceptor(){

    }
}
