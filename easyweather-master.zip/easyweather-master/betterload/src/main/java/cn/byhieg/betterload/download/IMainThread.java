package cn.byhieg.betterload.download;

/**
 * Created by byhieg on 17/3/14.
 * Contact with byhieg@gmail.com
 */

public interface IMainThread{

    void post(Runnable runnable);
}
